import { useNavigate } from 'react-router-dom';
import { useFastAuth } from '@/hooks/useFastAuth';
import { useDarkMode } from '@/shared/components/DarkModeProvider';
import { useLanguage } from '@/contexts/LanguageContext';
import { 
  Store, 
  TrendingUp, 
  Users, 
  Award, 
  ShoppingBag, 
  BarChart,
  Zap,
  ArrowLeft
} from 'lucide-react';
import { EnhancedHero } from '@/components/home/EnhancedHero';
import { EnhancedFeatureGrid } from '@/components/home/EnhancedFeatureCard';
import { EnhancedButton } from '@/components/ui/EnhancedButton';
import { EnhancedCard, EnhancedStatCard } from '@/components/ui/EnhancedCard';
import { motion } from 'framer-motion';

const EnhancedIndexPage = () => {
  const navigate = useNavigate();
  const { user, profile, signOut } = useFastAuth();
  const { isDarkMode, toggleDarkMode } = useDarkMode();
  const { language, toggleLanguage } = useLanguage();

  const handleNavigate = (path: string) => {
    if (!user) {
      navigate('/auth');
      return;
    }
    navigate(path);
  };

  const handleDashboardClick = () => {
    if (!user) {
      navigate('/auth');
      return;
    }
    if (profile?.role === 'admin') {
      navigate('/admin/dashboard');
    } else if (profile?.role === 'affiliate' || profile?.role === 'marketer') {
      navigate('/affiliate');
    } else if (profile?.role === 'merchant') {
      navigate('/merchant');
    } else {
      navigate('/');
    }
  };

  const features = [
    {
      icon: Store,
      title: 'متاجر متعددة',
      description: 'أنشئ وأدر متجرك الإلكتروني بسهولة مع أدوات قوية ومرنة',
      gradient: 'bg-gradient-to-br from-blue-500 to-cyan-500',
      onClick: () => handleNavigate('/affiliate/store')
    },
    {
      icon: TrendingUp,
      title: 'نظام العمولات',
      description: 'اربح عمولات تنافسية على كل عملية بيع من خلال نظام ذكي',
      gradient: 'bg-gradient-to-br from-green-500 to-emerald-500',
      onClick: () => handleNavigate('/affiliate/commissions')
    },
    {
      icon: Users,
      title: 'التحالفات',
      description: 'انضم لتحالفات المسوقين وضاعف أرباحك من خلال العمل الجماعي',
      gradient: 'bg-gradient-to-br from-purple-500 to-pink-500',
      onClick: () => handleNavigate('/affiliate')
    },
    {
      icon: Award,
      title: 'نظام النقاط',
      description: 'اكسب نقاط وارتقي في المستويات من برونزي إلى أسطوري',
      gradient: 'bg-gradient-to-br from-yellow-500 to-orange-500',
      onClick: () => handleNavigate('/affiliate')
    },
    {
      icon: ShoppingBag,
      title: 'إدارة المنتجات',
      description: 'أضف وعدّل منتجاتك بسهولة مع نظام إدارة متكامل',
      gradient: 'bg-gradient-to-br from-red-500 to-rose-500',
      onClick: () => handleNavigate('/products')
    },
    {
      icon: BarChart,
      title: 'تقارير تفصيلية',
      description: 'تابع أداءك بتقارير شاملة ورسوم بيانية تفاعلية',
      gradient: 'bg-gradient-to-br from-indigo-500 to-blue-500',
      onClick: () => handleNavigate('/admin/analytics')
    }
  ];

  const stats = [
    {
      icon: Users,
      title: 'المسوقين النشطين',
      value: '2,547',
      change: { value: 12.5, positive: true },
      gradient: 'bg-gradient-to-br from-blue-500 to-cyan-500'
    },
    {
      icon: ShoppingBag,
      title: 'المنتجات المتاحة',
      value: '8,234',
      change: { value: 8.3, positive: true },
      gradient: 'bg-gradient-to-br from-green-500 to-emerald-500'
    },
    {
      icon: TrendingUp,
      title: 'إجمالي المبيعات',
      value: '127,456 ر.س',
      change: { value: 15.2, positive: true },
      gradient: 'bg-gradient-to-br from-purple-500 to-pink-500'
    }
  ];

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 pointer-events-none">
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3]
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute -top-1/2 -right-1/2 w-full h-full bg-gradient-to-br from-primary/20 to-accent/20 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1.2, 1, 1.2],
            opacity: [0.3, 0.5, 0.3]
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 4
          }}
          className="absolute -bottom-1/2 -left-1/2 w-full h-full bg-gradient-to-tr from-accent/20 to-primary/20 rounded-full blur-3xl"
        />
      </div>

      {/* Header */}
      {user && (
        <motion.header
          initial={{ y: -100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="relative z-10 border-b border-border/50 backdrop-blur-xl bg-surface/30"
        >
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <motion.div
                  whileHover={{ rotate: 360 }}
                  transition={{ duration: 0.6 }}
                  className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center shadow-lg"
                >
                  <Zap className="w-6 h-6 text-white" />
                </motion.div>
                <div>
                  <p className="text-sm text-muted-foreground">مرحباً</p>
                  <p className="font-semibold text-foreground">
                    {profile?.full_name || user?.email || 'ضيف'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <EnhancedButton
                  variant="ghost"
                  size="sm"
                  onClick={toggleLanguage}
                >
                  {language === 'ar' ? 'EN' : 'ع'}
                </EnhancedButton>
                <EnhancedButton
                  variant="ghost"
                  size="sm"
                  onClick={toggleDarkMode}
                >
                  {isDarkMode ? '☀️' : '🌙'}
                </EnhancedButton>
                <EnhancedButton
                  variant="outline"
                  size="sm"
                  onClick={signOut}
                >
                  تسجيل الخروج
                </EnhancedButton>
              </div>
            </div>
          </div>
        </motion.header>
      )}

      {/* Main Content */}
      <div className="relative z-10 container mx-auto px-4 py-16">
        {/* Hero Section */}
        <EnhancedHero isDarkMode={isDarkMode} />

        {/* Stats Section */}
        {user && (
          <motion.section
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="mb-20"
          >
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {stats.map((stat, index) => (
                <EnhancedStatCard key={stat.title} {...stat} />
              ))}
            </div>
          </motion.section>
        )}

        {/* Features Section */}
        <motion.section
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          <div className="text-center mb-12">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-4xl font-bold mb-4"
            >
              اكتشف الميزات
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-muted-foreground text-lg"
            >
              كل ما تحتاجه لبناء تجارتك الإلكترونية في منصة واحدة
            </motion.p>
          </div>

          <EnhancedFeatureGrid features={features} />
        </motion.section>

        {/* CTA Section */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1 }}
          className="mt-20"
        >
          <EnhancedCard variant="gradient" className="text-center p-12">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              className="w-20 h-20 mx-auto mb-6 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center shadow-2xl"
            >
              <Award className="w-10 h-10 text-white" />
            </motion.div>

            <h2 className="text-3xl font-bold mb-4">
              {user ? 'جاهز لبدء رحلتك؟' : 'ابدأ رحلتك معنا'}
            </h2>
            <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
              انضم لآلاف المسوقين والتجار الذين حققوا نجاحهم من خلال منصتنا
            </p>

            {user ? (
              <EnhancedButton
                variant="gradient"
                size="lg"
                icon={ArrowLeft}
                onClick={handleDashboardClick}
                glow
                pulse
              >
                الذهاب للوحة التحكم
              </EnhancedButton>
            ) : (
              <EnhancedButton
                variant="gradient"
                size="lg"
                icon={ArrowLeft}
                onClick={() => navigate('/auth')}
                glow
                pulse
              >
                ابدأ الآن مجاناً
              </EnhancedButton>
            )}
          </EnhancedCard>
        </motion.section>
      </div>
    </div>
  );
};

export default EnhancedIndexPage;
