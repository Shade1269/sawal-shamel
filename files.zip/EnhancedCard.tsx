import { motion, HTMLMotionProps } from 'framer-motion';
import { cn } from '@/lib/utils';
import { LucideIcon } from 'lucide-react';

interface EnhancedCardProps extends Omit<HTMLMotionProps<'div'>, 'ref'> {
  variant?: 'default' | 'glass' | 'gradient' | 'bordered';
  hoverable?: boolean;
  clickable?: boolean;
  glow?: boolean;
  children: React.ReactNode;
}

export const EnhancedCard = ({
  variant = 'default',
  hoverable = true,
  clickable = false,
  glow = false,
  className,
  children,
  ...props
}: EnhancedCardProps) => {
  const variants = {
    default: 'bg-surface border border-border',
    glass: 'bg-surface/50 backdrop-blur-xl border border-border/50',
    gradient: 'bg-gradient-to-br from-surface to-surface-2 border border-border',
    bordered: 'bg-surface border-2 border-primary/20'
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={hoverable ? { y: -4, scale: 1.01 } : undefined}
      whileTap={clickable ? { scale: 0.98 } : undefined}
      className={cn(
        'rounded-2xl p-6 transition-all duration-300 relative overflow-hidden',
        variants[variant],
        hoverable && 'hover:shadow-xl hover:border-primary/30',
        clickable && 'cursor-pointer',
        className
      )}
      {...props}
    >
      {/* Glow Effect */}
      {glow && (
        <motion.div
          className="absolute inset-0 bg-gradient-to-br from-primary/10 to-accent/10 opacity-0 group-hover:opacity-100 transition-opacity"
          animate={{
            background: [
              'linear-gradient(135deg, rgba(var(--primary), 0.1), rgba(var(--accent), 0.1))',
              'linear-gradient(225deg, rgba(var(--accent), 0.1), rgba(var(--primary), 0.1))',
              'linear-gradient(135deg, rgba(var(--primary), 0.1), rgba(var(--accent), 0.1))'
            ]
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      )}

      {/* Shine Effect */}
      {hoverable && (
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent"
          whileHover={{
            x: [-200, 400],
          }}
          transition={{
            duration: 1,
            ease: "easeInOut"
          }}
        />
      )}

      <div className="relative z-10">{children}</div>
    </motion.div>
  );
};

// Stat Card
interface StatCardProps {
  icon: LucideIcon;
  title: string;
  value: string | number;
  change?: {
    value: number;
    positive: boolean;
  };
  gradient: string;
}

export const EnhancedStatCard = ({
  icon: Icon,
  title,
  value,
  change,
  gradient
}: StatCardProps) => {
  return (
    <EnhancedCard variant="glass" hoverable glow className="group">
      <div className="space-y-4">
        {/* Icon & Change */}
        <div className="flex items-start justify-between">
          <motion.div
            whileHover={{ rotate: [0, -10, 10, 0], scale: 1.1 }}
            transition={{ duration: 0.5 }}
            className={cn(
              'w-12 h-12 rounded-xl flex items-center justify-center shadow-lg',
              gradient
            )}
          >
            <Icon className="w-6 h-6 text-white" />
          </motion.div>

          {change && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className={cn(
                'px-2 py-1 rounded-lg text-sm font-semibold flex items-center gap-1',
                change.positive ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500'
              )}
            >
              <span>{change.positive ? '↑' : '↓'}</span>
              <span>{Math.abs(change.value)}%</span>
            </motion.div>
          )}
        </div>

        {/* Title */}
        <div>
          <p className="text-sm text-muted-foreground mb-1">{title}</p>
          <motion.p
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 100 }}
            className="text-3xl font-bold text-foreground"
          >
            {value}
          </motion.p>
        </div>

        {/* Progress Bar */}
        <div className="h-1 bg-surface-2 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: '100%' }}
            transition={{ duration: 1, delay: 0.2, ease: "easeOut" }}
            className={cn('h-full', gradient)}
          />
        </div>
      </div>
    </EnhancedCard>
  );
};

// Product Card
interface ProductCardProps {
  image: string;
  title: string;
  price: number;
  originalPrice?: number;
  badge?: string;
  onClick?: () => void;
}

export const EnhancedProductCard = ({
  image,
  title,
  price,
  originalPrice,
  badge,
  onClick
}: ProductCardProps) => {
  return (
    <EnhancedCard variant="glass" clickable hoverable onClick={onClick} className="group">
      <div className="space-y-4">
        {/* Image Container */}
        <div className="relative aspect-square rounded-xl overflow-hidden bg-surface-2">
          {badge && (
            <motion.div
              initial={{ x: -100 }}
              animate={{ x: 0 }}
              className="absolute top-3 right-3 px-3 py-1 bg-accent text-white text-xs font-bold rounded-full z-10"
            >
              {badge}
            </motion.div>
          )}
          
          <motion.img
            src={image}
            alt={title}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
            whileHover={{ scale: 1.1 }}
          />

          {/* Overlay on Hover */}
          <motion.div
            initial={{ opacity: 0 }}
            whileHover={{ opacity: 1 }}
            className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4"
          >
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="w-full py-2 bg-white text-primary rounded-lg font-semibold"
            >
              أضف للسلة
            </motion.button>
          </motion.div>
        </div>

        {/* Info */}
        <div className="space-y-2">
          <h3 className="font-semibold text-foreground line-clamp-2 group-hover:text-primary transition-colors">
            {title}
          </h3>
          
          <div className="flex items-center gap-2">
            <span className="text-xl font-bold text-primary">
              {price} ر.س
            </span>
            {originalPrice && (
              <span className="text-sm text-muted-foreground line-through">
                {originalPrice} ر.س
              </span>
            )}
          </div>
        </div>
      </div>
    </EnhancedCard>
  );
};

// Info Card
interface InfoCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  action?: {
    label: string;
    onClick: () => void;
  };
}

export const EnhancedInfoCard = ({
  icon: Icon,
  title,
  description,
  action
}: InfoCardProps) => {
  return (
    <EnhancedCard variant="bordered" hoverable>
      <div className="flex gap-4">
        <motion.div
          whileHover={{ rotate: 360 }}
          transition={{ duration: 0.6 }}
          className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0"
        >
          <Icon className="w-6 h-6 text-primary" />
        </motion.div>

        <div className="flex-1 space-y-2">
          <h3 className="font-semibold text-foreground">{title}</h3>
          <p className="text-sm text-muted-foreground">{description}</p>
          
          {action && (
            <motion.button
              whileHover={{ x: 5 }}
              onClick={action.onClick}
              className="text-primary text-sm font-medium flex items-center gap-1 mt-2"
            >
              {action.label}
              <span>←</span>
            </motion.button>
          )}
        </div>
      </div>
    </EnhancedCard>
  );
};
