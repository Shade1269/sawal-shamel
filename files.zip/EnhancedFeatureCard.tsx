import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  gradient: string;
  delay?: number;
  onClick?: () => void;
}

export const EnhancedFeatureCard = ({
  icon: Icon,
  title,
  description,
  gradient,
  delay = 0,
  onClick
}: FeatureCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      whileHover={{ y: -8, scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className="group relative cursor-pointer"
    >
      {/* Glow Effect */}
      <div className={cn(
        "absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 blur-xl transition-opacity duration-500",
        gradient
      )} />

      {/* Card */}
      <div className="relative h-full bg-surface/80 backdrop-blur-sm border border-border hover:border-primary/50 rounded-2xl p-6 transition-all duration-300 overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute top-0 right-0 w-32 h-32 opacity-5">
          <div className={cn("w-full h-full rounded-full", gradient)} />
        </div>

        {/* Content */}
        <div className="relative space-y-4">
          {/* Icon Container */}
          <motion.div
            whileHover={{ rotate: [0, -10, 10, -10, 0], scale: 1.1 }}
            transition={{ duration: 0.5 }}
            className="relative"
          >
            <div className={cn(
              "w-14 h-14 rounded-xl flex items-center justify-center",
              gradient,
              "shadow-lg group-hover:shadow-xl transition-shadow"
            )}>
              <Icon className="w-7 h-7 text-white" />
            </div>
            
            {/* Pulse Ring */}
            <motion.div
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0.5, 0, 0.5]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className={cn(
                "absolute inset-0 rounded-xl",
                gradient,
                "opacity-0 group-hover:opacity-50"
              )}
            />
          </motion.div>

          {/* Title */}
          <h3 className="text-xl font-bold text-foreground group-hover:text-primary transition-colors">
            {title}
          </h3>

          {/* Description */}
          <p className="text-muted-foreground leading-relaxed">
            {description}
          </p>

          {/* Hover Arrow */}
          <motion.div
            initial={{ x: -10, opacity: 0 }}
            whileHover={{ x: 0, opacity: 1 }}
            className="flex items-center gap-2 text-primary font-medium"
          >
            <span className="text-sm">استكشف المزيد</span>
            <motion.span
              animate={{ x: [0, 5, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            >
              ←
            </motion.span>
          </motion.div>
        </div>

        {/* Shine Effect */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent"
          animate={{
            x: [-200, 400],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            repeatDelay: 5,
            ease: "easeInOut"
          }}
        />
      </div>
    </motion.div>
  );
};

// Grid Container
interface FeatureGridProps {
  features: Array<{
    icon: LucideIcon;
    title: string;
    description: string;
    gradient: string;
    onClick?: () => void;
  }>;
}

export const EnhancedFeatureGrid = ({ features }: FeatureGridProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
      {features.map((feature, index) => (
        <EnhancedFeatureCard
          key={feature.title}
          {...feature}
          delay={0.2 + index * 0.1}
        />
      ))}
    </div>
  );
};
