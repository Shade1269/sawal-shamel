import { motion, HTMLMotionProps } from 'framer-motion';
import { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';
import { ButtonLoading } from './EnhancedLoading';

interface EnhancedButtonProps extends Omit<HTMLMotionProps<'button'>, 'ref'> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'gradient';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  icon?: LucideIcon;
  iconPosition?: 'left' | 'right';
  loading?: boolean;
  glow?: boolean;
  pulse?: boolean;
  fullWidth?: boolean;
}

export const EnhancedButton = ({
  children,
  variant = 'primary',
  size = 'md',
  icon: Icon,
  iconPosition = 'right',
  loading = false,
  glow = false,
  pulse = false,
  fullWidth = false,
  className,
  disabled,
  ...props
}: EnhancedButtonProps) => {
  const variants = {
    primary: 'bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg hover:shadow-xl',
    secondary: 'bg-secondary text-secondary-foreground hover:bg-secondary/80',
    outline: 'border-2 border-primary text-primary hover:bg-primary/10',
    ghost: 'text-primary hover:bg-primary/10',
    gradient: 'bg-gradient-to-r from-primary to-accent text-white shadow-lg hover:shadow-2xl'
  };

  const sizes = {
    sm: 'px-4 py-2 text-sm',
    md: 'px-6 py-3 text-base',
    lg: 'px-8 py-4 text-lg',
    xl: 'px-10 py-5 text-xl'
  };

  const buttonClasses = cn(
    'relative rounded-xl font-semibold transition-all duration-300',
    'disabled:opacity-50 disabled:cursor-not-allowed',
    'active:scale-95',
    'overflow-hidden',
    variants[variant],
    sizes[size],
    fullWidth && 'w-full',
    className
  );

  return (
    <motion.button
      whileHover={{ scale: disabled ? 1 : 1.02 }}
      whileTap={{ scale: disabled ? 1 : 0.98 }}
      className={buttonClasses}
      disabled={disabled || loading}
      {...props}
    >
      {/* Glow Effect */}
      {glow && !disabled && (
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-primary/50 to-accent/50 blur-xl"
          animate={{
            opacity: [0.5, 0.8, 0.5],
            scale: [1, 1.1, 1]
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      )}

      {/* Pulse Effect */}
      {pulse && !disabled && (
        <motion.div
          className="absolute inset-0 rounded-xl bg-white"
          animate={{
            scale: [1, 1.5],
            opacity: [0.3, 0]
          }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
            ease: "easeOut"
          }}
        />
      )}

      {/* Shine Effect */}
      {!disabled && (
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
          animate={{
            x: [-200, 400],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            repeatDelay: 2,
            ease: "easeInOut"
          }}
        />
      )}

      {/* Content */}
      <span className="relative flex items-center justify-center gap-2">
        {loading ? (
          <ButtonLoading loading={loading}>{children}</ButtonLoading>
        ) : (
          <>
            {Icon && iconPosition === 'left' && (
              <motion.span
                whileHover={{ x: -2 }}
                transition={{ duration: 0.2 }}
              >
                <Icon className="w-5 h-5" />
              </motion.span>
            )}
            {children}
            {Icon && iconPosition === 'right' && (
              <motion.span
                whileHover={{ x: 2 }}
                transition={{ duration: 0.2 }}
              >
                <Icon className="w-5 h-5" />
              </motion.span>
            )}
          </>
        )}
      </span>
    </motion.button>
  );
};

// Icon Button
interface IconButtonProps extends Omit<HTMLMotionProps<'button'>, 'ref'> {
  icon: LucideIcon;
  variant?: 'primary' | 'secondary' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  label?: string;
}

export const EnhancedIconButton = ({
  icon: Icon,
  variant = 'ghost',
  size = 'md',
  label,
  className,
  ...props
}: IconButtonProps) => {
  const variants = {
    primary: 'bg-primary text-primary-foreground hover:bg-primary/90',
    secondary: 'bg-secondary text-secondary-foreground hover:bg-secondary/80',
    ghost: 'text-foreground hover:bg-surface'
  };

  const sizes = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-12 h-12'
  };

  const iconSizes = {
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-6 h-6'
  };

  return (
    <motion.button
      whileHover={{ scale: 1.1, rotate: 5 }}
      whileTap={{ scale: 0.9 }}
      className={cn(
        'rounded-full flex items-center justify-center transition-all',
        'relative overflow-hidden group',
        variants[variant],
        sizes[size],
        className
      )}
      aria-label={label}
      {...props}
    >
      {/* Ripple Effect */}
      <motion.span
        className="absolute inset-0 bg-white rounded-full"
        initial={{ scale: 0, opacity: 0.5 }}
        whileTap={{ scale: 2, opacity: 0 }}
        transition={{ duration: 0.4 }}
      />
      
      <Icon className={cn(iconSizes[size], 'relative z-10')} />
    </motion.button>
  );
};

// Button Group
interface ButtonGroupProps {
  children: React.ReactNode;
  className?: string;
}

export const ButtonGroup = ({ children, className }: ButtonGroupProps) => {
  return (
    <div className={cn('flex gap-3 flex-wrap', className)}>
      {children}
    </div>
  );
};

// Floating Action Button
interface FABProps extends Omit<HTMLMotionProps<'button'>, 'ref'> {
  icon: LucideIcon;
  label?: string;
}

export const FloatingActionButton = ({ icon: Icon, label, ...props }: FABProps) => {
  return (
    <motion.button
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
      className="fixed bottom-8 left-8 w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-full shadow-2xl flex items-center justify-center z-50 group"
      aria-label={label}
      {...props}
    >
      {/* Glow */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-br from-primary to-accent rounded-full blur-xl opacity-50"
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.5, 0.8, 0.5]
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
      
      <Icon className="w-7 h-7 text-white relative z-10 group-hover:rotate-90 transition-transform duration-300" />
      
      {/* Tooltip */}
      {label && (
        <motion.span
          initial={{ opacity: 0, x: 20 }}
          whileHover={{ opacity: 1, x: 0 }}
          className="absolute right-full mr-4 px-3 py-2 bg-surface border border-border rounded-lg text-sm whitespace-nowrap shadow-lg"
        >
          {label}
        </motion.span>
      )}
    </motion.button>
  );
};
